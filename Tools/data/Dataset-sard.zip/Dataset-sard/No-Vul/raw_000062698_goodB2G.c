static void goodB2G()
{
    int data;
    int dataArray[5];
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    dataArray[2] = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_66b_goodB2GSink(dataArray);
}
