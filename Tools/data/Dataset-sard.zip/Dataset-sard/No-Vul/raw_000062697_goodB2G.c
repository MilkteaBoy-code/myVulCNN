static void goodB2G()
{
    int data;
    void (*funcPtr) (int) = CWE121_Stack_Based_Buffer_Overflow__CWE129_large_65b_goodB2GSink;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    funcPtr(data);
}
