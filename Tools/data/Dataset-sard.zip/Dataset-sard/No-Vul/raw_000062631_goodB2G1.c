static void goodB2G1()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Read data from the console using fscanf() */
    fscanf(stdin, "%d", &data);
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_22_goodB2G1Global = 0; /* false */
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_22_goodB2G1Sink(data);
}
