static void goodB2G()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_67_structType myStruct;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_67b_goodB2GSink(myStruct);
}
