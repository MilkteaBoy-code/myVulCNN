static void goodB2G()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_68_goodB2GData = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_68b_goodB2GSink();
}
