static void goodG2B()
{
    int data;
    void (*funcPtr) (int) = CWE121_Stack_Based_Buffer_Overflow__CWE129_large_65b_goodG2BSink;
    /* Initialize data */
    data = -1;
    /* FIX: Use a value greater than 0, but less than 10 to avoid attempting to
     * access an index of the array in the sink that is out-of-bounds */
    data = 7;
    funcPtr(data);
}
